﻿using System;


namespace $safeprojectname$
{
    public class Class1
    {
        static void Main()
        {
            Console.WriteLine("Hello World!");
            Console.ReadKey();
        }
    }
}
